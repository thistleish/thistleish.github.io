﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace God_sFavorite
{
    internal class Program
    {
        static void Main()
        {

            //change console title
            Console.Title = "God's Favorite";

            //instantiate game & menu
            Game game = new Game();
            Menu menu = new Menu(game);

            //instantiate player and god

            //menu method
            menu.CreateMenu();

            //call scene 1 method
            game.Scene1();
            Console.ReadKey();

            //determine what branch of scene 2 to run
            game.DetermineScene2();
            Console.ReadKey();

            //determine what ending to run
            game.DetermineEnding();
            Console.ReadKey();
            
        }
    }
}
