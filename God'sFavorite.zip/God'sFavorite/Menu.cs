﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace God_sFavorite
{
    internal class Menu
    {

        // make game
        Game game;

        //this fixes playerName being overridden to the default constantly
        public Menu(Game game)
        {
            this.game = game;
        }

        //variable that tells me if the menu is active
        bool menuRunning = true;

        string title = @"
                                   ..                 .x+=:.                               _                                     .         s               
                                 dF          .8u     z`    ^%        oec :                u                                     @88>      :8               
                           u.   '88bu.      m888R-      .   <k      @88888               88Nu.   u.         u.      .u    .     %8P      .88               
             uL      ...ue888b  '*88888bu    98P      .@8Ned8""      8""*88%        u     '88888.o888c  ...ue888b   .d88B :@8c     .      :888ooo      .u    
         .ue888Nc..  888R Y888r   ^""*8888N   ^8     .@^%8888""       8b.        us888u.   ^8888  8888  888R Y888r =""8888f8888r  .@88u  -*8888888   ud8888.  
        d88E`""888E`  888R I888>  beWE ""888L  J""    x88:  `)8b.     u888888> .@88 ""8888""   8888  8888  888R I888>   4888>'88""  ''888E`   8888    :888'8888. 
        888E  888E   888R I888>  888E  888E +""     8888N=*8888      8888R   9888  9888    8888  8888  888R I888>   4888> '      888E    8888    d888 '88%"" 
        888E  888E   888R I888>  888E  888E         %8""    R88      8888P   9888  9888    8888  8888  888R I888>   4888>        888E    8888    8888.+""    
        888E  888E  u8888cJ888   888E  888F          @8Wou 9%       *888>   9888  9888   .8888b.888P u8888cJ888   .d888L .+     888E   .8888Lu= 8888L      
        888& .888E   ""*888*P""   .888N..888         .888888P`        4888    9888  9888    ^Y8888*""""   ""*888*P""    ^""8888*""      888&   ^%888*   '8888c. .+ 
        *888"" 888&     'Y""       `""888*""""          `   ^""F          '888    ""888*""""888""     `Y""         'Y""          ""Y""        R888""    'Y""     ""88888%   
         `""   ""888E                 """"                               88R     ^Y""   ^Y'                                           """"                ""YP'    
        .dWi   `88E                                                  88>                                                                                   
        4888~  J8%                                                   48                                                                                    
         ^""===*""`                                                    '8                                                                                    
        ";
        //font: fraktur
        //from patorjk.com

        string options = "1) Play\n2) Instructions\n3) Credits\n4) Exit\n\n**Note: please zoom out and scroll up until you can see the entirety of the title in the console! thanks :)\n";
       
        
        //string[] options = new string[]
        //{
        //    "1) play",
        //    "2) instructions",
        //    "3) credits",
        //    "4) exit"
        //};



        public void CreateMenu()
        {
            while (menuRunning)
            {


                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();

                //print game title
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(title);
                Console.ResetColor();

                //ask user to choose an option
                Console.WriteLine("Choose an option below.\n\n");
                Console.WriteLine(options);
                string input = Console.ReadLine();

                //taking in response
                MenuChoice(input);
            }
        }

        //process the player's choice
        private void MenuChoice(string input)
        {
            switch (input)
            {

                case "1":
                    StartGame();
                    menuRunning = false;
                    break;

                case "2":
                    ShowInstructions();
                    break;

                case "3":
                    ShowCredits();
                    break;

                case "4":
                    Console.WriteLine("Exiting game...");
                    Console.ReadLine();
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("\nInvalid input. Please enter a number 1-4 to select an option.");
                    Console.ReadLine();

                    CreateMenu();
                    break;
            }
        }


        //start game method
        private void StartGame()
        {
            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();
            Console.WriteLine("Thank you for playing God's Favorite!\nEntering game...");
            Console.ReadLine();


            game.Introduction();
        }


        //instructions method
        private void ShowInstructions()
        {
            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();
            Console.WriteLine("In order to choose a dialogue option, enter the corresponding number 1-4, then press enter.");
            Console.WriteLine("\nThere are mid-game branches and five endings. Your choices influence the outcome--can you get them all?");
            Console.WriteLine("\nPress enter to return to the menu.");
            Console.ReadLine();

            CreateMenu();
        }

        //credits method
        private void ShowCredits()
        {
            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();
            Console.WriteLine("God's Favorite");
            Console.WriteLine("Made by Thistle Rich");
            Console.WriteLine("2025");
            Console.WriteLine("\nSpecial thanks to my friend Nora for indulging my Asteraoth obesession and encouraging my writing. Couldn't have done it without you. <3");
            Console.WriteLine("\nPress enter to return to the menu.");
            Console.ReadLine();

            CreateMenu();
        }

    }
}
