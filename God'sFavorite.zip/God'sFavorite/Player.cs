﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace God_sFavorite
{
    public class Player : Character
    {
        //variables
        public int bloodstained = 0;
        public int conviction = 0;
        public int recklessness = 0;
        public int asteraothTotal = 0;
        public string playerName = "Asteraoth";

        public override void Dialogue(string dialogue, Player player)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(dialogue);
            Console.ResetColor();
        }
    }
}
