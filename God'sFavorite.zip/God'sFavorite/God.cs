﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace God_sFavorite
{
    public class God : Character
    {

        //variables
        public int wrath = 0;
        public int mercy = 0;
        public int intrigue = 0;

        //dialogue method
        ////allows me to easily write god's dialogue in yellow
        public override void Dialogue(string dialogue, Player player)
        {
            //changes the color
            Console.ForegroundColor = ConsoleColor.Yellow;

            //replaces {playerName} with the variable
            string formattedText = dialogue.Replace("{playerName}", player.playerName);

            //writes the dialogue, then resets color
            Console.WriteLine(formattedText);
            Console.ResetColor();


        }
    }
}
