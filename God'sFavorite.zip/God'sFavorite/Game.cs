﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace God_sFavorite
{
    public class Game
    {
        //variables
        int query;
        

        //instantiate objects

        Player player = new Player();
        God god = new God();
        Story story = new Story();
        Ascii ascii = new Ascii();

        //determine scene 2 branch method
        public void DetermineScene2()
        {
            if (player.conviction > player.recklessness && player.conviction > player.bloodstained)
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                Scene2Conviction(player);
            }                      

            else if (player.recklessness > player.bloodstained && player.recklessness > player.conviction)
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                Scene2Recklessness(player);
            }

            else if (player.bloodstained > player.conviction && player.bloodstained > player.recklessness)
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                Scene2Bloodstained(player);
            }

            else if (player.conviction <= 1)
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                Scene2Hesitation(player);
            }

            else
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                Scene2Hesitation(player);
            }
        }

        //determine ending method
        public void DetermineEnding()
        {
            if (player.asteraothTotal == 8)
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                EndingAsteraoth(player);
            }

            else if (god.wrath > god.mercy && god.wrath > god.intrigue)
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                EndingFallenAngel(player);
            }

            else if (god.mercy > god.wrath && god.mercy > god.intrigue)
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                EndingForgiveness(player);
            }


            else if (god.intrigue > god.wrath && god.intrigue > god.mercy)
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                EndingCatAndMouse(player);
            }

            else
            {
                Console.Clear();
                Console.WriteLine("\x1b[3J");
                Console.Clear();
                EndingDefault(player);
            }
        }



        //ALL SCENE METHODS BELOW

        //introduction method
        public void Introduction()
        {
            //50th fix i'm trying to get console.clear to clear everything and not just what it can see
            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();
            //code from alex on stackoverflow. everybody say thank you alex

            //Console.WriteLine($"DEBUG: before introduction initial text. playerName = '{player.playerName}'");

            Console.WriteLine(story.Introduction[0]);
            Console.ReadLine();
            Console.WriteLine(story.Introduction[1]);
            Console.ReadLine();
            Console.WriteLine(story.Introduction[2]);

            //Console.WriteLine($"DEBUG: immediately before the name query. playerName = '{player.playerName}'");
            //name query
            player.playerName = Console.ReadLine();

            //Console.WriteLine($"DEBUG: immediately after the name query. playerName = '{player.playerName}'");
            //check for aster easter egg
            if (player.playerName == "Asteraoth")
            {
                god.Dialogue(story.GodDialogue[70], player);
                Console.ReadLine();
            }

            else 
            {
                god.Dialogue(story.GodDialogue[69], player);
                Console.ReadLine();
            }

            //Console.WriteLine($"DEBUG: right before the console clears at the very end of introduction method. playerName = '{player.playerName}'");
            //Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

        }

        //scene 1 method
        public void Scene1()
        {

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //first query
            Console.WriteLine(ascii.AsciiArt[0]);
            Console.WriteLine(story.Scene1[0]);
            Console.WriteLine(story.Scene1[1]);

            //Console.WriteLine($"DEBUG: playerName = '{player.playerName}'");

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Scene1[2]);
                    player.conviction += 1;
                    player.bloodstained -= 2;
                    break;
                    
                case 2:
                    Console.WriteLine(story.Scene1[3]);
                    player.recklessness += 1;
                    player.bloodstained += 1;
                    player.asteraothTotal += 1;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();


            //second query and answers
            Console.WriteLine(story.Scene1[4]);

            query = Convert.ToInt32(Console.ReadLine());

            switch(query)
            {
                case 1:
                    Console.WriteLine(story.Scene1[5]);
                    player.conviction += 1;
                    player.asteraothTotal += 1;
                    break; 
                
                case 2:
                    Console.WriteLine(story.Scene1[6]);
                    player.recklessness += 1; 
                    player.bloodstained += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Scene1[7]);
                    player.recklessness -= 1;
                    break;

                case 4:
                    Console.WriteLine(story.Scene1[8]);
                    player.conviction -= 2;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //third query and answers
            Console.WriteLine(ascii.AsciiArt[4]);
            Console.WriteLine(story.Scene1[9]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
                {
                    case 1:
                        Console.WriteLine(story.Scene1[10]);
                        player.bloodstained += 2;
                    player.recklessness += 1;
                    player.asteraothTotal += 1;
                        break;

                    case 2:
                        Console.WriteLine(story.Scene1[11]);
                        player.conviction -= 1;
                        break;

                    case 3:                        
                        Console.WriteLine(story.Scene1[12]);
                        player.conviction += 1;
                        player.recklessness += 1;
                        break;
                }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //fourth query and answers
            Console.WriteLine(story.Scene1[13]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)

            {
                case 1:
                    player.conviction -= 1;
                    player.recklessness += 2;
                    break;

                case 2:
                    player.bloodstained -= 1;
                    player.conviction += 1;
                    break;

                case 3:
                    player.asteraothTotal += 1;
                    break;
            }
            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

        }


        //scene 2 ; conviction
        public void Scene2Conviction(Player player)
        {
            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //first query
            Console.WriteLine(story.Conviction[0]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Conviction[1]);
                    god.mercy += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Conviction[2]);
                    god.intrigue += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Conviction[3]);
                    god.intrigue += 1;
                    god.wrath += 1;
                    break;
            }
            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //second query
            Console.WriteLine(story.Conviction[4]);
            god.Dialogue(story.GodDialogue[0], player);
            Console.WriteLine(story.Conviction[5]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Conviction[6]);
                    god.Dialogue(story.GodDialogue[1], player);
                    Console.WriteLine(story.Conviction[7]);
                    god.wrath += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Conviction[8]);
                    god.Dialogue(story.GodDialogue[2], player);
                    Console.WriteLine(story.Conviction[9]);
                    god.Dialogue(story.GodDialogue[3], player);
                    Console.WriteLine(story.Conviction[10]);
                    god.wrath += 1;
                    god.mercy -= 1;
                    break;

                case 3:
                    Console.WriteLine(story.Conviction[11]);
                    god.Dialogue(story.GodDialogue[4], player);
                    Console.WriteLine(story.Conviction[12]);
                    god.mercy += 1;
                    god.intrigue -= 1;
                    break;

                case 4:
                    Console.WriteLine(story.Conviction[13]);
                    god.Dialogue(story.GodDialogue[5], player);
                    Console.WriteLine(story.Conviction[14]);
                    god.intrigue += 1;
                    god.mercy -= 1;
                    break;
            }
            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //third query
            Console.WriteLine(story.Conviction[15]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Conviction[16]);
                    god.wrath -= 1;
                    break;

                case 2:
                    Console.WriteLine(story.Conviction[17]);
                    god.Dialogue(story.GodDialogue[6], player);
                    Console.WriteLine(story.Conviction[18]);
                    god.mercy += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Conviction[19]);
                    god.intrigue += 2;
                    god.wrath += 1;
                    break;

                case 4:
                    Console.WriteLine(story.Conviction[20]);
                    god.Dialogue(story.GodDialogue[7], player);
                    god.mercy += 1;
                    god.wrath -= 1;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            // fourth query
            Console.WriteLine(story.Conviction[21]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Conviction[22]);
                    god.intrigue += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Conviction[23]);
                    god.mercy += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Conviction[24]);
                    god.wrath += 1;
                    break;

                case 4:
                    Console.WriteLine(story.Conviction[25]);
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();
        }


        //scene 2 ; recklessness
        public void Scene2Recklessness(Player player)
        {
            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();


            //query 1
            Console.WriteLine(story.Reckless[0]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Reckless[1]);
                    god.mercy += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Reckless[2]);
                    god.intrigue += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Reckless[3]);
                    god.intrigue += 1;
                    god.wrath += 1;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 2
            Console.WriteLine(story.Reckless[4]);
            god.Dialogue(story.GodDialogue[8], player);
            Console.WriteLine(story.Reckless[5]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Reckless[6]);
                    god.Dialogue(story.GodDialogue[9], player);
                    god.intrigue += 1;
                    god.mercy += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Reckless[7]);
                    god.intrigue += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Reckless[8]);
                    god.wrath += 1; 
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 3
            Console.WriteLine(story.Reckless[9]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Reckless[10]);
                    god.wrath += 1;
                    god.mercy -= 1;
                    break;

                case 2:
                    Console.WriteLine(story.Reckless[11]);
                    god.mercy += 2;
                    break;

                case 3:
                    Console.WriteLine(story.Reckless[12]);
                    god.Dialogue(story.GodDialogue[10], player);
                    Console.WriteLine(story.Reckless[13]);
                    god.Dialogue(story.GodDialogue[11], player);
                    god.wrath -= 1;
                    god.intrigue += 1;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 4
            Console.WriteLine(story.Reckless[14]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Reckless[15]);
                    god.intrigue += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Reckless[16]);
                    god.mercy += 2;
                    god.wrath -= 1;
                    break;

                case 3:
                    Console.WriteLine(story.Reckless[17]);
                    god.Dialogue(story.GodDialogue[12], player);
                    Console.WriteLine(story.Reckless[18]);
                    god.wrath += 1;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();
        }
        

        //scene 2 ; bloodstained
        public void Scene2Bloodstained(Player player)
        {

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 1
            Console.WriteLine(story.Bloodstained[0]);
            god.Dialogue(story.GodDialogue[13], player);
            Console.WriteLine(story.Bloodstained[1]);
            god.Dialogue(story.GodDialogue[14], player);
            Console.WriteLine(story.Bloodstained[2]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Bloodstained[3]);
                    god.Dialogue(story.GodDialogue[15], player);
                    Console.WriteLine(story.Bloodstained[4]);
                    god.mercy += 1;
                    god.intrigue += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Bloodstained[5]);
                    god.Dialogue(story.GodDialogue[16], player);
                    Console.WriteLine(story.Bloodstained[6]);
                    god.intrigue += 2;
                    god.wrath += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Bloodstained[7]);
                    god.Dialogue(story.GodDialogue[17], player);
                    Console.WriteLine(story.Bloodstained[8]);
                    god.wrath += 1;
                    break;

                case 4:
                    Console.WriteLine(story.Bloodstained[9]);
                    god.Dialogue(story.GodDialogue[18], player);
                    god.intrigue += 1;
                    god.wrath -= 1;
                    player.asteraothTotal += 1;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 2
            Console.WriteLine(story.Bloodstained[10]);
            god.Dialogue(story.GodDialogue[19], player);
            Console.WriteLine(story.Bloodstained[11]);

            query = Convert.ToInt32(Console.ReadLine());


            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Bloodstained[12]);
                    god.Dialogue(story.GodDialogue[20], player);
                    Console.WriteLine(story.Bloodstained[13]);
                    god.intrigue -= 1;
                    god.wrath += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Bloodstained[14]);
                    god.Dialogue(story.GodDialogue[21], player);
                    Console.WriteLine(story.Bloodstained[15]);
                    god.mercy += 1;
                    god.wrath += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Bloodstained[16]);
                    god.Dialogue(story.GodDialogue[22], player);
                    Console.WriteLine(story.Bloodstained[17]);
                    god.intrigue += 2;
                    player.asteraothTotal += 1;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 3
            Console.WriteLine(story.Bloodstained[18]);
            god.Dialogue(story.GodDialogue[23], player);
            Console.WriteLine(story.Bloodstained[19]);

            query = Convert.ToInt32(Console.ReadLine());


            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Bloodstained[20]);
                    god.wrath += 2;
                    god.intrigue -= 1;
                    player.asteraothTotal += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Bloodstained[21]);
                    god.Dialogue(story.GodDialogue[24], player);
                    Console.WriteLine(story.Bloodstained[22]);
                    god.mercy += 2;
                    break;

                case 3:
                    Console.WriteLine(story.Bloodstained[23]);
                    god.Dialogue(story.GodDialogue[25], player);
                    Console.WriteLine(story.Bloodstained[24]);
                    god.mercy -= 1;
                    god.intrigue += 1;
                    god.wrath += 1;
                    break;
            }
            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 4
            Console.WriteLine(story.Bloodstained[25]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Bloodstained[26]);
                    god.intrigue += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Bloodstained[27]);
                    god.mercy += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Bloodstained[28]);
                    god.wrath += 2;
                    player.asteraothTotal += 1;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();
        }
        

        //scene 2 ; hesitation
        public void Scene2Hesitation(Player player)
        {
            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 1
            Console.WriteLine(story.Hesitation[0]);
            god.Dialogue(story.GodDialogue[26], player);
            Console.WriteLine(story.Hesitation[1]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Hesitation[2]);
                    god.Dialogue(story.GodDialogue[27], player);
                    Console.WriteLine(story.Hesitation[3]);
                    god.mercy += 1;
                    god.intrigue += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Hesitation[4]);
                    god.Dialogue(story.GodDialogue[28], player);
                    Console.WriteLine(story.Hesitation[5]);
                    god.Dialogue(story.GodDialogue[29], player);
                    god.mercy += 2;
                    god.intrigue -= 1;
                    break;

                case 3:
                    Console.WriteLine(story.Hesitation[6]);
                    god.Dialogue(story.GodDialogue[30], player);
                    Console.WriteLine(story.Hesitation[7]);
                    god.Dialogue(story.GodDialogue[31], player);
                    god.intrigue += 2;
                    god.wrath += 1;
                    break;
            }
            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 2
            Console.WriteLine(story.Hesitation[8]);
            god.Dialogue(story.GodDialogue[32], player);
            Console.WriteLine(story.Hesitation[9]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Hesitation[10]);
                    god.Dialogue(story.GodDialogue[33], player);
                    Console.WriteLine(story.Hesitation[11]);
                    god.mercy += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Hesitation[12]);
                    god.intrigue += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Hesitation[13]);
                    god.Dialogue(story.GodDialogue[34], player);
                    god.wrath += 1;
                    god.intrigue += 1; 
                    break;

                case 4:
                    Console.WriteLine(story.Hesitation[14]);
                    god.Dialogue(story.GodDialogue[35], player);
                    Console.WriteLine(story.Hesitation[15]);
                    god.wrath += 1;
                    god.intrigue -= 1;
                    god.mercy += 1;
                    break;
            }

            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 3
            Console.WriteLine(story.Hesitation[16]);
            god.Dialogue(story.GodDialogue[36], player);
            Console.WriteLine(story.Hesitation[17]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Hesitation[18]);
                    god.Dialogue(story.GodDialogue[37], player);
                    Console.WriteLine(story.Hesitation[19]);
                    god.wrath += 2;
                    break;

                case 2:
                    Console.WriteLine(story.Hesitation[20]);
                    god.Dialogue(story.GodDialogue[38], player);
                    Console.WriteLine(story.Hesitation[21]);
                    god.mercy += 2;
                    break;

                case 3:
                    Console.WriteLine(story.Hesitation[22]);
                    god.Dialogue(story.GodDialogue[39], player);
                    Console.WriteLine(story.Hesitation[23]);
                    god.intrigue += 1;
                    break;

                case 4:
                    Console.WriteLine(story.Hesitation[24]);
                    god.Dialogue(story.GodDialogue[40], player);
                    Console.WriteLine(story.Hesitation[25]);
                    god.intrigue += 2;
                    god.wrath += 1;
                    break;
            }
            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            //query 4
            Console.WriteLine(story.Hesitation[26]);
            god.Dialogue(story.GodDialogue[41], player);
            Console.WriteLine(story.Hesitation[27]);

            query = Convert.ToInt32(Console.ReadLine());

            switch (query)
            {
                case 1:
                    Console.WriteLine(story.Hesitation[28]);
                    god.mercy += 1;
                    break;

                case 2:
                    Console.WriteLine(story.Hesitation[29]);
                    god.Dialogue(story.GodDialogue[42], player);
                    Console.WriteLine(story.Hesitation[30]);
                    god.wrath += 1;
                    break;

                case 3:
                    Console.WriteLine(story.Hesitation[31]);
                    god.mercy += 1;
                    break;

                case 4:
                    Console.WriteLine(story.Hesitation[32]);
                    god.intrigue += 1;
                    break;
            }
            Console.ReadLine();

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();
        }

        
        //ending ; fallen angel
        public void EndingFallenAngel(Player player) 
        {

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            
            Console.WriteLine(story.FallenAngel[0]);
            god.Dialogue(story.GodDialogue[43], player);
            Console.ReadLine();
            Console.WriteLine(story.FallenAngel[1]);
            god.Dialogue(story.GodDialogue[44], player);
            Console.ReadLine();
            Console.WriteLine(story.FallenAngel[2]);
            god.Dialogue(story.GodDialogue[45], player);
            Console.ReadLine();
            Console.WriteLine(story.FallenAngel[3]);
            god.Dialogue(story.GodDialogue[46], player);
            Console.ReadLine();
            Console.WriteLine(story.FallenAngel[4]);
        }

        
        //ending ; forgiveness
        public void EndingForgiveness(Player player)
        {

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();


            Console.WriteLine(ascii.AsciiArt[2]);
            Console.WriteLine(story.Forgiveness[0]);
            god.Dialogue(story.GodDialogue[47], player);
            Console.ReadLine();
            Console.WriteLine(story.Forgiveness[1]);
            god.Dialogue(story.GodDialogue[48], player);
            Console.ReadLine();
            Console.WriteLine(story.Forgiveness[2]);
            god.Dialogue(story.GodDialogue[49], player);
            Console.ReadLine();
            Console.WriteLine(story.Forgiveness[3]);
            god.Dialogue(story.GodDialogue[50], player);
            Console.ReadLine();
            Console.WriteLine(story.Forgiveness[4]);
            god.Dialogue(story.GodDialogue[51], player);
            Console.ReadLine();
            Console.WriteLine(story.Forgiveness[5]);
            god.Dialogue(story.GodDialogue[52], player);
            Console.ReadLine();
            Console.WriteLine(story.Forgiveness[6]);
            god.Dialogue(story.GodDialogue[53], player);
            Console.ReadLine();
            Console.WriteLine(story.Forgiveness[7]);
        }


        //ending ; asteraoth
        public void EndingAsteraoth(Player player)
        {

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            Console.WriteLine(ascii.AsciiArt[5]);
            Console.WriteLine(story.Asteraoth[0]);
            god.Dialogue(story.GodDialogue[54], player);
            Console.ReadLine();
            Console.WriteLine(story.Asteraoth[1]);
            god.Dialogue(story.GodDialogue[55], player);
            Console.ReadLine();
            Console.WriteLine(story.Asteraoth[2]);
            god.Dialogue(story.GodDialogue[56], player);
            Console.ReadLine();
            Console.WriteLine(story.Asteraoth[3]);
            god.Dialogue(story.GodDialogue[57], player);
            Console.ReadLine();
            Console.WriteLine(story.Asteraoth[4]);
            god.Dialogue(story.GodDialogue[58], player);
            Console.ReadLine();
            Console.WriteLine(story.Asteraoth[5]);
            god.Dialogue(story.GodDialogue[59], player);
            Console.ReadLine();
            Console.WriteLine(story.Asteraoth[6]);
        }

        
        //ending ; cat and mouse
        public void EndingCatAndMouse(Player player)
        {

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            Console.WriteLine(ascii.AsciiArt[3]);
            Console.WriteLine(story.CatAndMouse[0]);
            god.Dialogue(story.GodDialogue[60], player);
            Console.ReadLine();
            Console.WriteLine(story.CatAndMouse[1]);
            god.Dialogue(story.GodDialogue[61], player);
            Console.ReadLine();
            Console.WriteLine(story.CatAndMouse[2]);
            god.Dialogue(story.GodDialogue[62], player);
            Console.ReadLine();
            Console.WriteLine(story.CatAndMouse[3]);
            god.Dialogue(story.GodDialogue[63], player);
            Console.ReadLine();
            Console.WriteLine(story.CatAndMouse[4]);
            god.Dialogue(story.GodDialogue[64], player);
            Console.ReadLine();
            Console.WriteLine(story.CatAndMouse[5]);
            god.Dialogue(story.GodDialogue[65], player);
            Console.ReadLine();
            Console.WriteLine(story.CatAndMouse[6]);
            god.Dialogue(story.GodDialogue[66], player);
            Console.ReadLine();
            Console.WriteLine(story.CatAndMouse[7]);
        }


        //ending ; default
        public void EndingDefault(Player player)
        {

            Console.Clear();
            Console.WriteLine("\x1b[3J");
            Console.Clear();

            Console.WriteLine(ascii.AsciiArt[1]);
            Console.WriteLine(story.DefaultEnding[0]);
            god.Dialogue(story.GodDialogue[67], player);
            Console.ReadLine();
            Console.WriteLine(story.DefaultEnding[1]);
            god.Dialogue(story.GodDialogue[68], player);
            Console.ReadLine();
            Console.WriteLine(story.DefaultEnding[2]);
        }

    }
}
