﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace God_sFavorite
{
    public class Character
    {
        public virtual void Dialogue(string dialogue, Player player)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(dialogue);
            Console.ResetColor();
        }
    }
}
