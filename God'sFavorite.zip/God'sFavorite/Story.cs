﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace God_sFavorite
{
    public class Story
    {
        //narrative array for introduction
        public string[] Introduction = new string[]
        {
            "Wake up.\n",

            "Come now, wake up, Angel.\n",
            
            "Oh, you poor thing. You must not remember any of it. Don’t worry, I’ll tell you.\nYou are God’s favorite angel. A pretty thing, with the blackest wings and the palest skin. Beautiful, divine. His. You wed last night, remember?\nHe laid you down and loved you, and He gave you the world--and you hated every second of it. You hated His smile, His eyes, the smell of ozone that clung heavy to His skin. You had never felt disgust before then. Now, it is the only thing you know.\nHave I jogged your memory, Angel? Good.\n\nYou must remember your name. Please, Angel, tell me what you wish to be called.\n",
        };

        //narrative array for scene 1
        public string[] Scene1 = new string[]
            {
                "Slowly, quietly, you sit up in the silken sheets of your marital bed. To your right, God lies in sleep, clothed only in the gauzy robes of an unguarded ruler. His peace sickens you. To be so content after defiling an angel--it makes bile rise into your throat. How horrible a creature, God is.\n\nA glinting light draws your blurring gaze, and all at once, you understand what must be done. As if possessed, your bare feet glide over marble floors to a pair of golden shears that hang on the far wall, displayed proudly as a spoil of a past war. You reach out and take them from the wall in dazed reverence. The weight of them is heavy in your hands. They’re sharp. They’re perfect.\n",

                //first query - index 1
                "On the blade are the remnants of the bloodshed it was born from--dried black flakes from the edge.\n\nAngel, do you clean the blade?\n1) Yes. Such things cannot be rushed. You are about to kill a God--mustn’t the act be divine?\n2) No. You don’t feel as if He deserves such a courtesy, and you’ve no time to waste. What you are about to do will be much messier.\n",



                //1
                "\nYou take a manicured fingernail to the metal, scraping bits of eons-old gore from it until it shines. With the blade clean, there is no more delaying the slaughter. The pair of shears held firmly in your grip, you step carefully back to the bedside. God is still fast asleep. You lean over Him, watching the rise and fall of his chest, and steady your breathing.\n",



                //2
                "\nThe shears remain crusted with ancient gore. With them held firmly in your grip, you step carefully back to the bedside. God is still fast asleep. You lean over Him, watching the rise and fall of his chest, and steady your breathing.\n",




                //second query - index 4
                "You are poised above Him, the shears in hand and extended. The tip of the blade comes to rest on His sternum.\n\nAngel, how do you begin?\n1) Deliberately. You bring the shears down into His skin as if it were a medical procedure and not a divine murder.\n2) With fervor. This must be done, and it must be done quickly. The only care you take in slicing Him open is ensuring that the cut is deep enough.\n3) With reverence. You may be defiling God, but he is still God. You press the blade down with a ritual awe.\n4) Hesitantly. The act you are about to perform is treason against the Heavens. It must be done, but you cannot be blamed for your caution.\n",



                //1
                "\nThe cut you make is clean. The skin splits like the warm fat of an animal beneath your holy blade. Within the confines of His chest, you find that golden blood into the void you create. His organs shift on their own--almost alive in their own right.\n",



                //2
                "\nYou plunge your shears into Him with enough force that His blood--golden, glittering, divine--spatters beyond your blade and onto the sheets beneath. Within the confines of His chest, you find that His organs shift on their own--almost alive in their own right. You’ve managed to slice through some of them.\n",



                //3
                "\nThe cut you make isn’t clean, but it’s beautiful. You run your hands down the lines of His holy chest and watch His golden blood well over the edge of the wound. Within the confines of His chest, you find that His organs shift on their own--almost alive in their own right.\n",



                //4
                "\nYour hands shake as the shears dive into the cavity of His chest. The cut is uneven, trembling. Golden blood spatters onto your hands due to the tremors. Within the confines of His chest, you find that His organs shift on their own--almost alive in their own right.\n",
                



                //third query - index 9
                "He is splayed open. Like this, He cannot hide. The convulsing of His glittering organs draws your attention--within Him, there must be a heart, surely.\n\nAngel, how do you reach it?\n1) With your bare hands. You reach into Him with only the goal of finding His heart and retrieving it.\n2) Nauseatingly. The sight of His writhing intestines sickens you. When you slide your hand into the hollow of His ribcage, you nearly weep at the feeling.\n3) With excitement. He’s beautiful--you want to experience Him in His fullest. You plunge your hand into the meat of Him, taking your time to feel His most intimate reaches.\n",
           

                
                //1
                "\nQuickly, and with no theatrics, you find it. A strong pulse settles into your grasp, and you pull your hand--with little resistance--to remove the source of His life.\n",
              


                //2
                "\nYou close your eyes as you reach into His gaping chest. The sensation of the shivering within sickens you--your fist closes around a pulsating mass and pulls to remove it. With no resistance, it slides out of His chest, and you find yourself with His heart grasped in your hand.\n",
               


                //3
                "\nThe sensation of it is ecstacy. Oh, to be so securely entwined with God in such a matter. Perhaps you delay your search for His heart longer than is necessary in order to revel in this blessing. Still--you cannot resist the pulsating mass that grazes your fingertips.\n",





                //fourth query - index 13
                "At last, the force of His being rests active in your palm. It’s captivating. The beating of it makes you shiver, unbidden. His blood catches the light with every fruitless pump of ever-flowing ichor.\n\nAngel, what do you feel at this moment?\n1) Disgusted. You hate every moment of this. Part of you wonders what you’ve done--have you made a mistake?\n2) Holy. How could you feel anything but divine with God’s entire existence in the palm of your hand?\n3) Nothing.\n",
            };


        //narrative arrays for scene 2 branches
        public string[] Conviction = new string[]
        {

            //first query - index 0 
            "\nWhile you’re examining the heart, you spot movement out of the corner of your eye. Horrifyingly, God begins to shift. His eyes are closed, yet you know two things for certain: He is alive, and He is watching you. Slowly and deliberately, He stands. The insides of Him spill carelessly down His front, smearing gold wherever they reach. They still writhe.\n\nAs His eyes open sleepily, they are locked on your form. His gaze does not waver; neither does yours. \n\nAngel, how do you react?\n1) In your shock, you drop the heart. You hardly notice--you have a much larger problem to worry about.\n2) You clutch the heart tighter. You must be careful not to give up your advantage so easily.\n3) Speak before He can. If He begins to talk, who knows what tricks He may use to sway your heart?\n",

            "\nThe heart drops wetly to the ground. It leaves a messy splatter of golden blood on impact--it spatters your calves and the hem of your white robes. God watches the heart fall, and His eyes slide back to you. He can hear the quiet gasping of your breath through your shock.\n",

            "\nGod notices your fingers tighten around the hefty muscle, and His gaze quickly snaps back to your face. There must be some expression on it that you are unaware of, as His eyes narrow. He seems to be taking you a little more seriously, now. Good.\n",

            "\n'What trick are you playing on me, Lord?'\n\nGod raises an eyebrow, but does not answer. You find Him utterly unreadable. Still, the silence is harrowing, you mustn’t let Him control the conversation.\n\n'I removed your heart. You can’t be alive--so what game do you think you’re playing? Is this an apparition? An illusion? A hallu--' A raised hand silences you, and you stop talking like a well-trained dog.\n",





            //query 2 - index 4

            "\nGod’s voice is smooth like the quiet lapping of water, but it contains a strange plurality that speaks of ancient power.\n", 
            
            //[0] 'You must have your reasons for this act of treason. Speak, {playerName}.'

            "\nAngel, how do you respond?\n1) Say nothing. He doesn’t deserve an explanation.\n2) 'You are unworthy of worship,' you spit.\n3) 'I had no choice.' It’s a plea, more than anything.\n4) Laugh. What an absurd question; is He truly pretending to care?\n",



            //1
            "/nYour silence says more than you think it does. Despite your lack of answer, God nods knowingly, as if you had told Him everything. His expression, however, is guarded.\n",
            
            //[1] 'Of course. You believe this was simply the only logical development, do you? That this was inevitable?'

            "\nStill, you remain quiet. You have convictions, morals to uphold. You refuse to let Him sway you.\n",





            //2
            "God hums, considering.\n",
            
            //[2] 'You believe so?'

            "\nWhat a stupid question. Of course you do. He hums once more, tilting His head at what must be a scathing expression that twists your face. He speaks once more.\n", 
            
            //[3] 'And I suppose you speak on behalf of all Angels.' 

            "\nIt’s condescending. It makes your blood boil. You wish to cut into Him once more, just to be cruel. Your lips form around words before you can think better of it.\n\n'You did not let the other Angels speak, so I did.'\n",





            //3
            "\nGod tsks at your pitiful appeal. It’s clear that He doesn’t buy it.\n", 
            
            //[4] '{playerName}, do you truly expect me to believe such a thing? You’re smarter than that.'
            
            "\nHe’s right. You are. But still, the panic seizes your throat and wrings the words from it unbidden. 'Please, Lord. What else was I to--'\n",





            //4
            "\nGod’s eyes narrow as you throw your head back and cackle. Through laughter, you manage to croak, 'You’re God. Does it matter? You will ruin me no matter what I say.'\n\nPerhaps it is true--you surely think it is. Still, God doesn’t appreciate being disrespected so blatantly. His voice is wrought with displeasure when He responds.\n\n", 
            
            //[5] 'Don’t mistake stupidity for courage, Angel.'

            "\n\nIt wrings another cackle from your throat. 'Then it seems a fool has managed to cut out your Heart, God.'\n",






            //query 3 - index 15 

            "\nHis expression darkens. You feel His presence around you more acutely, now--something unfathomable presses at the edges of your mind. He takes an inexorable step forward. Angel, what do you do?\n1) Move to attack. You must not let Him get to you before you get to Him.\n2) Run. He is God. Whatever He has planned for you, you want no part in.\n3) Stay standing. You are not scared of Him.\n4) Fall to your knees and beg.\n",





            //1
            "\nYou lunge, swiping desperately with the shears still dangling loosely in the fingers of your right hand. You must be quick--you move with all the power your legs will afford you to make an attempt to slash His throat.\n\nYou don’t get far enough. It feels as if you’ve been kicked in the ribs, though God hasn’t move an inch. You tumble to the ground, shears skittering far from your grasp. You didn’t even manage to draw blood, and now look where you’ve gotten?\n\nLungs try to find any remaining breath as you struggle to kneel, and God simply watches on as you cough up bile that invades your throat.\n",





            //2
            "\nYou turn away from Him and begin running. You have no destination in mind other than away, away, away. Adrenaline pumps your legs faster than you knew you were capable of. Your wings stay tucked as close behind you as you can manage, though tense and ready to take off if need be.\n\nYou get as far as the edge of the room before you are tripped by some invisible force that cements your feet in place. You crash to the ground and hang your head, panting. God is now upon you, standing over your heaving form with His hands folded neatly behind His back.\n",

            //[6] 'Did you really believe you had any chance of running from me, my dear?'
            
            "\nYou want to vomit.\n",





            //3
            "\nGod watches your face closely, scanning for any semblance of fear, regret, or anger. He only finds certainty.\n\nHis eyes wander down, taking in your still hands, your calm breaths. You do not tremble, you do not weep. You only stand upright, unmoving. Fearless.\n\nWhen His gaze meets yours once more, it is agitated; he appears to be annoyed by your conviction. He wants to get under your skin, and He can’t. His hands unfold from behind His back and suddenly, you double over in pain. It’s as if a kick has been delivered to your sternum--it knocks the wind out of you.\n\nYour legs ache from the impact, and your lungs gasp for air you hadn’t expected to lose. You look up at Him, eyes wide, and He looks… hollow. Like you were meant to be something greater, and have disappointed Him greatly.\n",





            //4
            "\nImmediately, you lower yourself to the ground and bow your head, clasping stained hands in front of you and weeping. 'Please, spare me,' you babble, 'There is nothing you will gain from hurting me. I’ll repay you, I promise.'\n\nHe is silent. Unmoving. You do not dare to raise your head, but He takes one step forward so His feet are within your view and bends at the waist, shrouding you in shadow.\n",
            
            //[7]'You’ve missed your chance, {playerName}.'






            //query 4 - index 21

            "\nYou are on your knees in front of Him, watching the yet-beating heart throb just out of reach. God says nothing, but you sense, in some prophetic manner, that this is the end; He has you right where He wants you. Angel, what do you do?\n1) Attempt to stand. You refuse to lay down and take it.\n2) Apologize. He’s already demonstrated that He could end your life in an instant. Why take that chance?\n3) Make a lunge for the heart. You must end Him, even in exchange for your own life.\n4) Do nothing. It’s pointless, by now.\n",





            //1
            "\nYour legs refuse to obey you, but you manage to get one foot underneath your weight. Your gaze tracks up God’s legs to His torso, still open and raw, and up to His face.\n",





            //2
            "\n'I’m sorry.'\n\nGod does not respond.\n\n'Please, I’m sorry. I was wrong. I was foolish, and stupid, and wrong.'\n\nYou raise your head, searching for any sign of forgiveness. Your eyes meet His.\n",





            //3
            "\nYou move with the last of your strength to grab the heart, and God simply steps in front of you. Through the gap between His legs, you can see the heart still beating on the floor. You won’t be able to get to it. \n\nSlowly, your head raises to meet God’s gaze.\n",





            //4
            "\nYou simply pant on the floor, making no move to do much of anything. Your body trembles. You know this is all futile, and you have no intention of making this harder for yourself than it already will be. \n\nA dripping golden hand rakes down your face as you raise your head, and through the shimmering gaps in your fingers, you watch God’s expression.\n",

        };

        public string[] Reckless = new string[]
        {
            // query 1 - index 0
            "\nWhile you’re examining the heart, you spot movement out of the corner of your eye. Horrifyingly, God begins to shift. His eyes are closed, yet you know two things for certain: He is alive, and He is watching you. Slowly and deliberately, He stands. The insides of Him spill carelessly down His front, smearing gold wherever they reach. They still writhe.\n\nHis eyes open as if He already knows what you’ve done--slowly, languidly. He’s almost sleepy in the way He moves, so unlike your own jittering hands, still clenched around the Heart so tight your knuckles creak.\n\nAngel, how do you react?\n1) In your shock, you drop the heart. You hardly notice--you have a much larger problem to worry about.\n2) You clutch the heart tighter. You must be careful not to give up your advantage so easily.\n3) Speak before He can. If He begins to talk, who knows what tricks He may use to sway your heart?",



            //1
            "\nThe heart drops wetly to the ground. It leaves a messy splatter of golden blood on impact--it spatters your calves and the hem of your white robes. God watches the heart fall, and His eyes slide back to you. He can hear the quiet gasping of your breath through your shock.\n",



            //2
            "\nGod notices your fingers tighten around the hefty muscle, and His gaze quickly snaps back to your face. There must be some expression on it that you are unaware of, as His eyes narrow. He seems to be taking you a little more seriously, now. Good.\n",



            //3
            "\n'What trick are you playing on me, Lord?'\n\nGod raises an eyebrow, but does not answer. You find Him utterly unreadable. Still, the silence is harrowing, you mustn’t let Him control the conversation.\n\n'I removed your heart. You can’t be alive--so what game do you think you’re playing? Is this an apparition? An illusion? A hallu--' A raised hand silences you, and you stop talking like a well-trained dog. \n",






            //query 2 - index 4 

            "\nWhen God speaks, His voice rattles like the sound of a thousand beating wings. It shakes something deep within you.\n\n",
            
            //[8] \n'You are bold. Do you believe fortune favors you?'\n
            
            "Angel, how do you respond?\n1) He is speaking nonsense--tell Him as much.\n2) Of course not. Deny it; you are not doing this to be favored.\n3) Why wouldn’t it? There’s no reason you would have got this far without luck.\n",



            //1
            "\n'Do you plan to say anything of worth? Neither of us have time for riddles.' God laughs, and the feathers of His voice tremble. Have you amused Him, or offended Him? You can’t tell.\n",

            //[9] \n'I suppose not.'\n



            //2
            "\n'Does it matter what I believe? Do you think so little of me as to assume I’m doing this for favor? No, of course not.' His eyes simply narrow. He does not speak--although He looks displeased.\n",



            //3
            "\nYou laugh yourself breathless. 'Of course it does! Am I not the boldest of the angels? I must be the most favored, then.' \n\nGod does not laugh along with you. He looks angry with your assertion. You find that you don’t much care.\n",





            // query 3 - index 9

            "\nGod steps forward, clasping His hands behind His back. The movement stretches His chest open wider, and a severed bit of gore falls out of the cavity and crawls its way back inside. He watches your reaction carefully, as if the display was choreographed. Are you imagining things, or is He being… cautious? He steps forward once more--this time, too close for comfort.\n\nAngel, what do you do?\n1) Strike first. You cannot afford to wait for His next move.\n2_ Step back. Distance is your only defense against whatever He has planned.\n3) Hold your ground. You refuse to be rattled, no matter what grotesque game He is playing. \n",



            //1
            "\nThere must be another source of life within Him, surely. You thrust yourself forward, aiming to tackle Him, reach inside of Him, and pull out whatever you can get your hands on. It’s futile. You fall short of the mark, your strength dwindling, and He simply steps aside, letting you tumble to the ground of your own accord.\n\nThe impact hurts, your joints creaking in protest. You have to take a moment to catch your breath; you didn’t even manage to touch Him, and now He has you at His mercy.\n",



            //2
            "\nYou take one measured, slow step back. God takes another one forward, pursuing.\n\nYou take one more. So does He.\n\nSoon, you are backed into a wall, unable to retreat any farther. He still approaches, and there’s nothing you can do to stop Him. On instinct, you slide down the wall to the ground, landing heavy on your knees.\n\nYou hang your head, half curled into a shivering mass on the floor.\n",



            //3
            "\nYou plant your feet, not letting yourself flinch, refusing to let Him see a flicker of uncertainty in your eyes.\n\nGod tilts His head, observing you.\n",
            
            //[10] \n'Unshaken, or only pretending to be?'\n
            
            "\nYou don’t answer. You won’t play along. An unseen force rams itself into your ribs, and it hurts so much that it sends you tumbling to the ground, scraping your limbs on the tile. Your previously rigid limbs tremble from the pain. God sounds disappointed.\n",

            //[11] \n'So it was a bluff, then.'\n






            //query 4 - index 14

            "\nYou are on your knees in front of Him, breath ragged, hands slick with blood--His, yours, it hardly matters. The heart still beats, taunting you. God’s silence tightens heavy around your throat like a noose, but you can feel it; this is your moment. Your only chance. \n\nAngel, what do you do?\n1) Claw your way forward. You don’t care what happens next, you just refuse to stop moving.\n2) Beg for forgiveness. You don’t want it to end like this--you don’t want it to end at all.\n3) Laugh in His face. If you’re going to die, you’ll do it mocking Him.\n",



            //1
            "\nYou grit your teeth and crawl, moving towards what, you aren’t sure. All you know is that you must continue, must keep moving, must not let Him win. You extend a hand, clawing desperately at the tile for something, anything. His heart is close enough that if you could manage just one more inch--\n\nA heavy foot plants itself firmly on your outstretched hand, and you know you have lost. You follow the lines of God’s leg up to His face and meet His eyes.\n",



            //2
            "\nYou drop whatever remains of your pride and press your forehead to the ground, hands grasping at the hem of His robe, at anything that might tether you to His mercy. 'Please,' you whisper, hoarse. Then louder, more desperate, 'Please, I was wrong--I was wrong, I’ll do anything--'\n\nThe weight of His silence settles heavy in your stomach, and you raise your head to meet His gaze with your own teary eyes.\n",



            //3
            "\nThe absurdity of it all--the blood, the beating heart, the spectacle he’s made of your suffering--it pushes past the fear and bubbles into laughter. It starts as a breathless chuckle, then gains momentum and grows until something full-bodied and reckless. It wracks your frame, causes your ribs to ache.\n\nGod says nothing at first, only watching, but there’s a shift in His expression. His smile is small, but gleams like the edge of a knife.\n",
            
            //[12] \n'Amusing. Shall I give you something to laugh about, then?'\n
            
            "\nAs you meet His eyes, the laughter dies in your throat.",

        };

        public string[] Bloodstained = new string[]
        {

            //query 1 - index 0 
            "\nWhile you’re examining the heart, you spot movement out of the corner of your eye. Horrifyingly, God begins to shift. His eyes are closed, yet you know two things for certain: He is alive, and He is watching you. Slowly and deliberately, He stands. The insides of Him spill carelessly down His front, smearing gold wherever they reach--although there is not much unstained skin left. They still writhe.\n\nGod does not recoil at the sight of you, though He should. His golden blood drips from your fingers, staining the ground, your skin, and your very soul. You have bathed in divinity, defiled it, and yet He stands before you. Unbroken. Untouched. His expression is unreadable, but the weight of His gaze alone is enough to suffocate you.\n",
            
            //[13] \n'You’ve made quite the mess, {playerName}.'\n
            
            "\nHis voice is light, conversational, but there is an unmistakable sharp edge beneath it.\n",
            
            //[14] \n'Was it worth it?'\n
            
            "\nAngel, how do you respond?\n1) You refuse to let Him see you falter. Grit your teeth and stand taller.\n2) Brace yourself for an attack. He will make the first move, and you refuse to fall so easily.\n3) Laugh. You don’t plan to stoop so low as to answer such useless questions.\n4) Speak. If this is your end, you will not be silent.\n",




            //1
            "\nYour body screams at you to kneel, to lower yourself before Him, but you will not cower. Not now.\n\nGod hums, as if considering you, as if turning you over in His mind like a puzzle to be solved. Then, He smiles. Small. Sharp. Knowing.\n",
            
            //[15] \n'Still so proud, even know. How charming.'\n
            
            "\nHis hand lifts, and for a fleeting second, you think He might strike you down where you stand. Instead, He brushes a golden-stained finger along your cheek, slow and deliberate.\n",




            //2
            "\nYour stance changes to be sturdier. Instinctively, you bring your gleaming hands up to defend your face, not attacking, but very clearly defending. \n\nGod huffs a breathless laugh--something small and almost genuine. Is your display so amusing to Him? Does He prefer you pretend as if He is not dangerous? His expression is… charmed.\n",
            
            //[16] \n'I am not a brute, Angel. I won’t attack you without provocation.'\n
            
            "\nYou scoff, still readied to defend. Liar.\n",




            //3
            "\nYour reckless laughter only causes a slight downward twitch in God’s lips and the raising of an eyebrow. His expression is endlessly amusing. You delight in His displeasure.\n",
            
            //[17] \n'This is funny?'\n
            
            "\nGod’s tone is not genuine, but discontent. Almost cautious. \n\nYou don’t respond, only giggle breathlessly.\n",




            //4
            "\n'Yes.'\n\nGod quirks an eyebrow at your short response, staying silent, encouraging you to continue.\n\n'I only aim to kill a sinner. There is nothing wrong with that.'\n\nGod nods, as if offering you that point. His voice is smooth and ancient when He responds, although cordial.\n",
            
            //[18] \n'True, I suppose.'\n






            //query 2 - index 5

            "\nGod tilts His head, watching you as if studying a dying thing. It hurts, to be scrutinized so closely. You become acutely aware of the sheer amount of viscera you’ve managed to splatter around the room. Your wrists are caked in it, it’s far under your fingernails, and the sheets on which you dissected God are drying a crisp gold. \n",
            
            //[19] \n'I wonder… do you even understand what you’ve done? Or is this all instinct to you--like a beast backed into a corner?'\n
            
            "\nAngel, how do you respond?\n1) Claim your actions. You have no regrets.\n2) Deny Him. You never meant for things to go this far.\n3) Say nothing. Any words you speak will doubtlessly be turned against you.\n",




            //1
            "\n'I understand full well what I have done.' You can’t ignore the blood that runs in visceral rivers down your arms and drips from your elbows. You’d have to be a fool to claim otherwise.\n",
            
            //[20] \n'And do you regret it?'\n
            
            "\nGod asks this question flatly, as if protocol.\n\n'No,' you answer.\n\nHe nods.\n",




            //2
            "\n'Lord, I never--I am not a beast. Simply--'\n\nHe holds up a hand to cease your nervous stammering, and interrupts you. \n",
            
            //[21] \n'But do you regret it?'\n
            
            "\nYour lips quiver, and it takes you too long to respond. 'Yes, Lord.'\n\nGod hardly acknowledges your answer.\n",




            //3
            "\nYou remain silent, letting the scene speak for itself. You are coated in the force of His life, it has soaked into your robes. No answer is needed for Him to understand. What you’ve done is done--there is nothing else that must be said.\n\nGod takes in your appearance and only asks one question:\n",
            
            //[22] \n'Do you regret it?'\n
            
            "\nNow, you speak. 'Who knows?'\n",






            //query 3 - index 9 

            "\nGod sighs, though there is no exasperation in His breath--only finality. You are unsure if He is disappointed in you, but that doesn’t feel right. It’s almost as if He’s treating you like a wild animal. Unpredictable, dangerous, and mindless. Is that really all He thinks of you?\n",
            
            //[23] \n'Then let us end this. I will not ask you again.'\n
            
            "\nAngel, what do you do?\n1) Strike first. Whatever happens, you will not cower.\n2) Plead with Him. Show Him you are more than an animal--you can regret.\n3) Reach for Him. If this is your end, let it be by His hands.\n",



            //1
            "\nYou lunge, putting every last ounce of strength into the motion. If He will end you, you will make Him work for it. You move with recklessness--wild, desperate, unrepentant.\n\nGod does not flinch. He does not raise a hand to stop you. He only watches, eyes half-lidded, as if He has already seen this before. As if He is already mourning the inevitable.\n\nYou don’t even reach Him.\n\nYour body locks in place, an invisible force binding you where you stand. Your limbs refuse to move. God takes a single step forward, and it is as if the world itself bends towards Him. \n\nHe mutters something to Himself, short, quiet, and then the force holding you snaps. All at once, the weight of your own defiance crushes you to the ground.\n",



            //2
            "\nYou take a breath that shakes your entire frame, and you fall to your knees in front of Him. Your throat tightens. You force yourself past your pride. 'I--I was wrong,' you admit, voice hoarse. 'Please, I--' Your own desperations chokes you.\n\nGod watches you, unreadable. His gaze does not soften. If anything, He seems to be studying you, measuring the weight of your words--the depth of your sincerity.\n\nHis voice is quiet, but it carries the weight of eternity.\n",
            
            //[24] \n'Do you truly regret it? Or do you simply regret what comes next?'\n
            
            "\nYou don’t know the answer. God does not give you the time to find it.\n",



            //3
            "\nYou exhale, slow and shuddering, and lift a trembling hand. Not to strike. Not to defend yourself. Just to touch.\n\nGod does not move away. He lets you reach Him.\n\nYour fingers brush against His robes, the fabric impossibly soft, impossibly clean. They pool around His waist, out of reach of His shivering organs. You grip the fabric as if it might anchor you, as if it might give you some shred of stability in a world slipping through your fingers.\n\nAnd then, He moves.\n\nHis hand catches your wrist, firm but not unkind. He tilts His head slightly, regarding you with something like curiosity--like pity. He murmurs.\n",
            
            //[25] \n'If only you had reached me sooner.'\n
            
            "\nThe warmth of His touch sears through you, and He slowly pushes you down until you are resting on your knees, staring reverently up at Him.\n",







            //query 4 - index 13

            "\nYour hands are slick with golden ichor as you watch Him. His heart, torn from its rightful place, pulses beyond your reach, staining the ground beneath it with something both holy and profane. The air is thick with the scent of divinity split open, of something that was never meant to be touched. And yet, He still stands. Watching. Waiting.\n\nHe does not move to stop you. He does not speak. He only lets you kneel there, trembling, breathless, drenched in the evidence of your defiance. But you can feel it--this is the moment. The last moment. If you hesitate now, it will be over.\n\nAngel, what do you do?\n1) Push yourself up. You are not done yet.\n2) Beg. You see now that you were never going to win.\n3) Spit at His feet. Let Him know you regret nothing.\n",


            //1
            "\nYou force yourself to your feet, ignoring the pain in your limbs. Every step feels like an eternity, but you will not stay down.\n\nGod watches, silent. There is no hint of approval in His gaze.\n",



            //2
            "\nYour head lowers, voice cracking. 'I never should have--'\n\nYou’ve done this before. You know it won’t end well. You cut yourself off, understanding that it’s futile. You simply raise your head again, finding His eyes and searching for something, anything.\n",



            //3
            "\nYou spit, and it mixes with the golden blood that has been spilled.\n\nGod’s eyes narrow, and He grips your jaw, forcing you to meet His gaze. He says nothing, only squeezes tight, and lets go after a moment.\n",

        };

        public string[] Hesitation = new string[]
        {

            //query 1 - index 0

            "While you’re examining the heart, you spot movement out of the corner of your eye. Horrifyingly, God begins to shift. His eyes are closed, yet you know two things for certain: He is alive, and He is watching you. Slowly and deliberately, He stands. The jagged edges of His wound let His insides spill down His front. His organs still writhe.\n\nGod watches you with something akin to disappointment. His face is calm, but you can still feel the weight of His judgement pressing down upon your shoulders. As His eyes open wider, your hands tremble--whether from fear or indecision, you do not know. Neither does He, and so He waits.\n",
            
            //[26] \n'You hesitate, {playerName}.
            
            "\nAngel, what do you do?\n1) Lower your head. You cannot meet His eyes.\n2) Speak--tell Him something, anything. The silence is unbearable.\n3) Do nothing. if He wants something from you. He must ask.\n",




            //1
            "\nYou lower your gaze, the weight of His stare too much to bear. Your heart races, and you wish for the ground to swallow you whole.\n\nGod’s voice is soft, but it cuts through you. You remember the way your shears felt slicing through His skin, and wonder if He feels that same twisted pleasure.\n",
            
            //[27] \n'You think I’ll be satisfied with submission?'\n
            
            "\nYou stay silent, attempting to hide from His questioning.\n",




            //2
            "\nYour voice shakes around the words. 'I… I don’t know what to say. Please--'\n\nHe interrupts you, impatient.\n",
            
            //[28] \n'Spare me your stammering, {playerName}. Only answer me this:'\n
            
            "\nHis voice drops low, soft, sweet.\n",
            
            //[29] \n'Why?'\n




            //3
            "\nYou stand frozen, refusing to ask unless He commands you.\n\nGod’s eyes gleam with amusement.\n",
            
            //[30] \n'When did you gather such courage, Angel?'\n
            
            "\nHe leans forward just slightly, as if truly engaged in this game He’s decided to play with you.\n",
            
            //[31] \n'When did you begin to believe you had power?'\n





            //query 2 - index 4 

            "His eyes, reeking of life, narrow. You feel pinned to some nonexistent wall behind you. Some sort of fear response has wound its way tightly into your veins, and you cannot move.\n",
            
            //[32] \n'You don’t know, do you?' \n
            
            "\nThere is no anger in His voice, but something worse: pity.\n\nAngel, how do you respond?\n1) Of course you know. You are not so blind as to ignore the trembling in your limbs.\n2) Say nothing; what could you possible say that He doesn’t already know?\n3) Step back. You are not ready for this.\n4) Try to explain. You must make Him understand--this had to be done.\n",



            //1
            "\nYou straighten yourself, but your body betrays you, shaking. 'Don’t think so little of me. My actions are my own, Lord.'\n\nGod’s lips curl slightly, but there’s no warmth in His smile.\n",
            
            //[33] \n'You thought you could change everything, didn’t you? Even now, you think you can still control it.'\n
            
            "\nYou attempt to hang onto that small thread of courage. You can. If there is anyone with the ability to right His wrongs, it’s you. All you can manage is to look Him in the eye and try to convince yourself of it.\n",



            //2
            "\nYou remain silent, the words lost in your throat, too heavy to speak. \n\nGod’s gaze pierces through you, needling and unavoidable. You know your silence speaks for itself, but you can’t bring yourself to say more.\n\nHe only watches you, observing every move of your smallest muscles. It is times like these you remember He is omnipotent.\n",



            //3
            "\nYou take a step back, but your legs betray you, and you stumble. Fear is nothing but a trap, and you certainly feel caught.\n\nHe scans you up, down, back up again. Takes in the trembling of your frame, your lowered head.",
            
            //[34] \n'So afraid, {playerName}. Do you think running will save you now?'\n



            //4
            "\nYou open your mouth to speak, but God has had enough of your feeble attempts to sway Him.\n",
            
            //[35] \n'Silence.'\n
            
            "\nThe command is not one you wish to disobey. You shut your mouth sharply, only able to look up at Him through quickly watering eyes and pray.\n",





            //query 3 - index 9

            "\nGod exhales, long and measured, as if He is making a harrowing decision of His own. There is a long moment before He speaks, during which you can only stare at the evidence of your treason dripping golden onto the floor beneath you.\n\nWhen He begins, it startles you.\n",
            
            //[36] \n'You are lost, little thing, but I am nothing if not patient. Let me help you decide.'\n
            
            "\nAngel, how do you react?\n1) Accuse Him of being a liar. You know Him--He is not kind, merciful, and certainly not patient.\n2) Reach out to Him in reverence. If He says He can help you, He will.\n3) Steady yourself, breathe deep. You will not appear weak before Him.\n4) Lost? Little thing? Does He take you for a child? Remind Him of His actions last night.\n",




            //1
            "\nYou meet His eyes with defiance, your voice steady despite the tremor in your hands. His expression is guarded. 'You are a liar, God. I’ve seen your true face. Out of everyone in the Heavens, I am the only one you cannot fool.'\n\nGod raises an eyebrow, amusement flickering briefly in His eyes before it disappears.\n",
            
            //[37] \n'Your anger changes nothing.'\n
            
            "\nYou resist the urge to snarl. 'It changes everything.'\n\nHe steps forward, unafraid of your display of malice.\n",



            //2
            "\nYour hands tremble as you stretch them towards Him, and unspoken plea for mercy. Your voice is soft, quiet, strained. Hopeful. 'If you truly want to help me, show me. Please.'\n\nGod’s gaze softens, though His eyes remain cold.\n",
            
            //[38] \n'You seek redemption, but do you deserve it, Angel?'\n
            
            "\nYour hands retreat, wondering if you do. The answer is no, it must be. But still, you can’t help yourself from yearning for mercy.\n",



            //3
            "\nYou close your eyes and take a deep breath, gathering the last dredges of strength from within your bones. When you open them again, you face Him with a firm resolve.\n\nGod watches you, silent, the smallest sliver of approval in His expression.\n",
            
            //[39] \n'Brave, but that won’t save you.'\n\

            "\nHe steps forward, and you will your body to stay put.\n",





            //4
            "\nYou step forward, your voice shaking with a mixture of righteous anger and indignation. 'You speak to me as if I am a child, but let us not forget what vile things you did to me last night.'\n\nGod’s expression falters, a hint of something darker passing through His eyes.\n",
            
            //[40] \n'And what of it? Do you think that changes your fate?'\n
            
            "\nYou shake your head. 'No. But it demands me some respect.'\n\nHe laughs, unamused, and it makes you shiver. Underneath your brashness, you realize you’re scared.\n",






            //query 4 - index 14

            "His fingers brush against your cheek--gentle, almost reverent. Like you are both below and above Him, something to be cherished, but as an object. His voice is a saccharine whisper. It makes your skin crawl, but with what emotion, you cannot place.\n",
            
            //[41] \n'You look so fragile when you tremble. What will it take to break you?'\n
            
            "\nAngel, what is your final act?\n1) Lean into His touch. He is offering you a way out--take it.\n2) Try to run. This false intimacy makes you sick, and you have to get away.\n3) Close your eyes. If He will destroy you, you do not wish to see it.\n4) Meet His gaze. You refuse to cower. Not now.\n",



            //1
            "\nYou feel the warmth of His fingers on your skin, and for a brief moment, you consider it--this fragile escape He offers. You allow yourself to lean into the touch, your breath slowly evening into regular inhales and exhales. \n\nGod’s smile deepens, but there’s no love behind it. His fingers pull away from your face, and the void they leave feels cold.\n\nYou open your eyes, though you don’t know when you closed them, to find Him staring at you, unwavering.\n",



            //2
            "\nWith a burst of energy, you pull back and attempt to move away. His touch lingers like a searing brand, but you manage to take a step back.\n\nGod watches you, displeasure flashing in His eyes.\n",
            
            //[42] \n'Running won’t save you. It never has.'\n
            
            "\nYou make the mistake of turning back, searching His expression for a sign of humanity, and your legs stop on their own when you meet His gaze.\n",



            //3
            "\nYou shut your eyes tight, bracing for whatever fate awaits you. You are unwilling to witness the cruelty He has in store.\n\nGod’s fingers trace your face, down your jaw and brushing lightly over the curve of your neck. This is dangerous, but you know He was always going to be. You are unafraid. It’s the end. You are going to let it remain the end.\n\nWhen His fingers do not sink in and kill you, your eyes crack open ever so slightly to find Him watching you. \n",


            
            //4
            "\nYou meet His stare, unflinching. You will not show weakness, not even in the face of His cruelty.\n\nThe silence between you is thick with tension. Neither of you speak. Neither of you yield. Both you and God simply observe each other. Silent. Shivering. Calculating.\n\nHe seems to find what He’s looking for before you do, as His expression twists.\n"

        };


        //narrative arrays for endings
        public string[] FallenAngel = new string[]
        {

            "\nGod’s eyes are hard, angry, and mean. As He looks at you, shivers run up your spine from the weight of His fury. He is disgusted with you.\n",
            
            //[43] \n'You have committed treason, {playerName}.'\n
            
            "\nHis voice carries the will of the Heavens in the flat tones of its pitches. It seems to shake the very foundations of the sky, it is so full of malice.\n\nYou open your mouth to speak, but you can manage no words. What is there to say? He is right--you committed treason. You tried to kill Him. Your fingers twitch around the memory of your golden shears.\n\nGod does not ask if you regret it. You think He knows the answer. You’re sure He doesn’t care.\n\nFor too many moments, the world rings silent beneath the terrible anger that distorts His face. The only mercy you are given is that He has not yet spoken your fate. \n\nAnd then He moves.\n\nThe sky breaks apart like shattered glass with the force of His hand against your throat, but it does not fall--only ceases. There is no sky, there is only HIm; His wrath incarnate, crushing the breath from you lungs as He lifts you from where you kneel as if you weigh nothing at all.\n",
            
            //[44] \n'I should kill you where you stand.'\n
            
            "\nYou believe Him. He could. He would. You claw weakly at the fingers around your neck as they seem to brand your skin with unknown heat, but they do not budge. You choke around them, desperate.\n\nHe muses, as if you are of no greater concern to Him than a passing thought.\n",
            
            //[45] \n'And yet, that would be too kind.'\n
            
            "\nHis face is closer to yours, now. His artificial breath grazes your cheeks, mocking the burning in your own straining lungs. There is no comfort to be found in the warmth.\n",
            
            //[46] \n'Hell was made for creatures like you.'\n
            
            "\nYour vision turns to spots that seep in around the edges. Your legs kick fruitlessly. Your lips shape soundlessly around a plea as He watches you impassively as you try. Try to save yourself. Try--\n\nAnd then you are falling.\n\nThe wind rushes past you, screaming in your ears as you tumble head over heels into the abyss below. You cannot wail, you cannot see, you can only feel the weight of your sins dragging you down. \n\nAbove you, the sky reforms, and God turns away.\n"

        };

        public string[] Forgiveness = new string[]
        {

            "God sighs, and it reeks of pity. You dare not raise your eyes for fear of His expression--you’re sure you don’t want to see it. You’ve disappointed Him. \n",
            
            //[47] \n'{playerName}, you regret what you did, don’t you?'\n
            
            "\nIf it were anyone else speaking for you, you’d kill them for the audacity to assume. But with God, you find yourself questioning. Do you? The golden blood under your fingernails burns. You think you do.\n\nGod nods--you’re not sure how you know this, as through your watering eyes it’s difficult to see even your own hands, but you know He does--and speaks as though you have spoken aloud.\n",
            
            //[48] \n'Of course. You’re sensible, aren’t you?'\n
            
            "\nYou nod. You’re reasonable. You can be reasonable. Again, He speaks like this is more than a one-sided monologue--perhaps it is.\n",
            
            //[49] \n'You understand, then, what I must do.'\n
            
            "\nAt this, your head raises. You cannot think, for the fear crawling through your veins. No, He cannot, no-- 'No, please, you mustn’t. You-- I am sorry. I never should have--' Panicked, you attempt to wipe the remaining wet blood from the creases in your palm, as if that will absolve you of sin. 'I was wrong. Please, I will take any punishment, just don’t cast me down.'\n\nYour terror has cleared your eyes, and now you can see Him. He looks sad. \n",
            
            //[50] \n'And what else would you deserve?'\n
            
            "\nIt’s a reasonable question. The only answer you can come up with is nothing.\n\nGod laughs, and it feels like a wooden stake through your lungs. You hang your head once more, but God bends down to take your chin in His hands and smile.\n",
            
            //[51] \n'So you are sensible, {playerName}.'\n
            
            "\nHe looks deep into your eyes, still smiling, though it does not reach His eyes. \n",
            
            //[52] \n'Come back. I’ll let you return. Forget all of this, and I will forgive the treason you have committed. We can live peacefully again, can’t we?'\n
            
            "\nYou think you see the corners of His lips twitch into something cruel, but you must be hallucinating. You’ve not enough oxygen, the tears have you dehydrated, surely. You nod, desperate. Your voice croaks when you speak, 'Of course. Yes, I’ll-- we can. I’ll never do anything like this again.'\n",
            
            //[53] \n'Good.'\n
            
            "\nAnd that’s all He says before leaving you to crawl after Him like the loyal dog you are.\n"

        };

        public string[] Asteraoth = new string[]
        {

            "\nThe hole in His chest gapes. The wound’s edges are clean, precise, almost beautiful.\n\nYou take closer note of the way His organs look. They catch the light and shine as they wriggle and squirm, knitting themselves back together slowly. Crawling intestines, lungs and muscles undulate under His skin. As the tissue writhes, it squelches, wet and twitching.\n\nHis insides--the viscera, the gore, the blood--all of it moves. The rest of Him is eerily still, as if carved from marble.\n\nHe speaks in a silk voice, garbled only by an influx of bubbling blood in His throat.\n",
            
            //[54] \n'{playerName}.'\n
            
            "\nYou do not answer, only watch as a clump of tissue begins to congeal in God’s open body.\n",
            
            //[55] \n'You have attempted to kill me--'\n
            
            "\nThe mass grows, more golden gore slithering its way under His ribcage. It molds itself to the cavity around it--sparkling sinew tethers it to His stitched blood vessels. Slowly, the new organ stutters to life.\n",
            
            //[56] \n'--And you have failed.'\n
            
            "\nThump. Thump. The new heart in His chest beats soundly, loudly. You cast a glance to the one you were holding just a moment ago, and it is finally still.\n\nThe old heart begins to blacken, melting into crude oil that carries a depth like the night sky. It boils along the grout lines of the tile where you kneel. It works its way to you, as if alive. You cannot stop it, and you do not try.\n\nAs the ink begins to touch your hands, it burns. It’s corrosive, eating away at your flesh and ripping pained moans from your vocal cords. It winds its way up your elbows, and the golden blood that stained your fingers burns black and joins it. \n\nYou scrabble at your neck as the oil brands you. It’s choking, all-consuming, and you can think of nothing put how much it hurts. You gasp for breath that you cannot find.\n\nIt is an eternity before the fiery pain at your neck ceases, and you retch, hacking up nothing. You have barely taken a full breath before God speaks.\n",
            
            //[57] \n'You are to be banished from the Heavens.'\n
            
            "\nHe pauses to watch tears carve glistening lines down your face. He continues.\n",
            
            //[58] \n'You are to be bound to my soul for the rest of time. For as long as I live, so too shall you.'\n
            
            "\nStill, you do not meet His gaze. You only stare at your stained robes as the oil begins to stink of rot. It leaves no stain on your clothing, but begins to coalesce. It weaves into a liquid halo of spikes above your head. Black, endless.\n\nYou look up to God’s face through heaven breaths, pinning deep black eyes onto His own golden ones. \n\nHe smiles politely at your snarl. Hands clasped behind His back and posture upright.\n\n'You will not survive me,' you spit. \n\nHe laughs, tittering, like your suffering amuses Him greatly.\n",
            
            //[59] \n'I’m sure I will.'\n
            
            "\nAnd you fall.\n"

        };

        public string[] CatAndMouse = new string[]
        {

            "\nGod watches you with something that might be curiosity, or it might be amusement. The corners of His mouth twitch imperceptibly; He is entertained.\n",
            
            //[60] \n'You are fascinating, {playerName}.'\n
            
            "\nHis voice is warm, light, teasing. It is wrong. You are trembling, barely holding yourself upright, and He--He is delighted.\n",
            
            //[61] \n'Most would have bowed their head and begun to beg, by now. You’re upright.'\n
            
            "\nHe takes a step forward. You take a step back. His smile widens, flashing sharp, white teeth that blind in the gold light of the Heavens.\n",
            
            //[62] \n'You aren’t afraid of me, are you?'\n
            
            "\nThe way He asks it is condescending. He knows the answer: you’re terrified. He can see it in the way your breath hitches on every inhale, in the way your stained hands clench around nothing but memory, in the way your body refuses to still itself, flight instinct twitching like a bird with clipped wings.\n\nBut He asks anyway, because it pleases Him.\n\nAfter you do not answer, He hums, taking another slow step forward, and then another, until you are backed against something--nothing--the very edge of what exists. His voice is hushed, as if He is confiding in you. \n",
            
            //[63]\n'I should punish you.'\n
            
            "\nIt is a threat and a promise, both. It’s a game. He’s having fun. \n\nYour voice shakes when you finally find it. 'Then do it.'\n\nIn the instant the words leave your lips, His smile is wiped from His face as if it were never there. What little warmth you could find in His face freezes over, and you regret speaking--existing, everything you have ever done up to this moment.\n\nAnd then He laughs.\n",
            
            //[64] \n'Oh, I do like you.'\n
            
            "\nHe reaches out; you flinch, but He does not strike. Instead, He lifts your chin with one finger, watching you through heavy-lidded eyes as if trying to find some answer in your face. His other hand brushes against your shoulder then comes to brush against your throat, light and quivering. It’s so gentle, it makes you hurt worse than any blow could.\n",
            
            //[65] \n'Run.'\n
            
            "\nIt’s another whisper. Your breath catches, His fingers slip silken away from your skin. He steps back, and the darkness in His eyes shimmers with something wild. Something like a predator.\n",

            //[66] \n'Go on. Run.'\n
            
            "\nHe will chase you, and He will catch you. You know this.\n\nYou run anyway.\n"

        };

        public string[] DefaultEnding = new string[]
        {

            "\nGod looks you up and down--it’s judgement, you realize. He is deciding what to do with you. How pointless; you know He’s decided it long ago.\n",
            
            //[67] \n'You are to never return, {playerName}.'\n
            
            "\nHis tone is not as if He is giving news--you both knew this was coming. It seems that He’s given up the pretense of mercy, or forgiveness, or anger. You are going to be cast down. That’s that.\n\nYou nod. 'And you will strip me of my wings, I suppose?'\n\nGod thinks about it for a second. This time, what He says is a surprise.\n",
            
            //[68] \n'No.'\n
            
            "\n'No?' you ask. Your tone is strangely bewildered. You want to ask Him why, but He would not answer you in any meaningful way. Instead, your eyes scan His face. There’s a hint of unfathomable age beneath the smooth lines of His nose, and disappointment etched into the curve of His jaw.\n\nAh. You see. He doesn’t want you to be a mortal, He wants you to be a fallen angel. There is no worse punishment than walking among humans while being something distinctly not. Stripping you of your wings would only provide you some meager comfort--you would be unable to use them, anyway. \n\nSo, He does have some grudge against you for this. Not unexpected.\n\nAs you watch His organs continue to stitch themselves back together, the still heart on the ground to your left begins to dissolve into black oil. It seeps into the white tile, flowing along the grout lines and staining your fingers in ink.\n\nA new heart builds itself within His chest and begins to beat. His skin melts back into one clean surface, and it’s as if nothing ever happened.\n\nWhen He curses you, He does not touch you. He hardly looks at you. You hear His words, chanting some ancient language you are not privy to, and then feel the sensation of falling. You cannot catch yourself, you will never be able to.\n\nYou do not know if the ground hurts when you crash into it.\n"

        };


        //array for god's dialogue

        public string[] GodDialogue = new string[]
        {
            //scene 2 ; conviction

            "\n'You must have your reasons for this act of treason. Speak, {playerName}.'\n",

           "\n'Of course. You believe this was simply the only logical development, do you? That this was inevitable?'\n",

           "\n'You believe so?'\n",

           "\n'And I suppose you speak on behalf of all Angels.'\n",

           "\n'{playerName}, do you truly expect me to believe such a thing? You’re smarter than that.'\n",

           "\n'Don’t mistake stupidity for courage, Angel.'\n",

           "\n'Did you really believe you had any chance of running from me, my dear?'\n",

           "\n'You’ve missed your chance, {playerName}.'\n",

           "\n'You are bold. Do you believe fortune favors you?'\n",

           "\n'I suppose not.'\n",

           "\n'Unshaken, or only pretending to be?'\n",

           "\n'So it was a bluff, then.'\n",

           "\n'Amusing. Shall I give you something to laugh about, then?'\n",

           "\n'You’ve made quite the mess, {playerName}.'\n",

           "\n'Was it worth it?'\n",

           "\n'Still so proud, even know. How charming.'\n",

           "\n'I am not a brute, Angel. I won’t attack you without provocation.'\n",

           "\n'This is funny?'\n",

           "\n'True, I suppose.'\n",

           "\n'I wonder… do you even understand what you’ve done? Or is this all instinct to you--like a beast backed into a corner?'\n",

           "\n'And do you regret it?'\n",

           "\n'But do you regret it?'\n",

           "\n'Do you regret it?'\n",

           "\n'Then let us end this. I will not ask you again.'\n",

           "\n'Do you truly regret it? Or do you simply regret what comes next?'\n",

           "\n'If only you had reached me sooner.'\n",

           "\n'You hesitate, {playerName}.'\n",

           "\n'You think I’ll be satisfied with submission?'\n",

           "\n'Spare me your stammering, {playerName}. Only answer me this:'\n",

           "\n'Why?'\n",

           "\n'When did you gather such courage, Angel?'\n",

           "\n'When did you begin to believe you had power?'\n",

           "\n'You don’t know, do you?' \n",

           "\n'You thought you could change everything, didn’t you? Even now, you think you can still control it.'\n",

           "\n'So afraid, {playerName}. Do you think running will save you now?'\n",

           "\n'Silence.'\n",

           "\n'You are lost, little thing, but I am nothing if not patient. Let me help you decide.'\n",

           "\n'Your anger changes nothing.'\n",

           "\n'You seek redemption, but do you deserve it, Angel?'\n",

           "\n'Brave, but that won’t save you.'\n",

           "\n'And what of it? Do you think that changes your fate?'\n",

           "\n'You look so fragile when you tremble. What will it take to break you?'\n",

           "\n'Running won’t save you. It never has.'\n",

           "\n'You have committed treason, {playerName}.'\n",

           "\n'I should kill you where you stand.'\n",

           "\n'And yet, that would be too kind.'\n",

           "\n'Hell was made for creatures like you.'\n",

           "\n'{playerName}, you regret what you did, don’t you?'\n",

           "\n'Of course. You’re sensible, aren’t you?'\n",

           "\n'You understand, then, what I must do.'\n",

           "\n'And what else would you deserve?'\n",

           "\n'So you are sensible, {playerName}.'\n",

           "\n'Come back. I’ll let you return. Forget all of this, and I will forgive the treason you have committed. We can live peacefully again, can’t we?'\n",

           "\n'Good.'\n",

           "\n'{playerName}.'\n",

           "\n'You have attempted to kill me--'\n",

           "\n'--And you have failed.'\n",

           "\n'You are to be banished from the Heavens.'\n",

           "\n'You are to be bound to my soul for the rest of time. For as long as I live, so too shall you.'\n",

           "\n'I’m sure I will.'\n",

           "\n'You are fascinating, {playerName}.'\n",

           "\n'Most would have bowed their head and begun to beg, by now. You’re upright.'\n",

           "\n'You aren’t afraid of me, are you?'\n",

           "\n'I should punish you.'\n",

           "\n'Oh, I do like you.'\n",

           "\n'Run.'\n",

           "\n'Go on. Run.'\n",

           "\n'You are to never return, {playerName}.'\n",

           "\n'No.'\n",

           "\nIt suits you. Now, you're ready to begin.\n\nGood luck, {playerName}.",

           "\nYou, again? {playerName}, you cannot change the outcome. You cannot defeat Him.\n\n...\n\nYou aren't going to listen to me, are you?\nFine. Be my guest. I'll be here when you die once more, little birdie."
        };


    }
}
